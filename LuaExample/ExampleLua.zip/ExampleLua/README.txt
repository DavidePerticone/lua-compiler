main.lua is the main file, the one that is given to the compiler.
The other two (stack.lua, Math.lua), are "libraries/modules" included 
in the main usage.

To run the program, just type lli output.ll